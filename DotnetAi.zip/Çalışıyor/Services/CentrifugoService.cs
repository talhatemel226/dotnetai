﻿using Newtonsoft.Json;
using System.Text;

namespace talhatemel.Services
{
    public static class CentrifugoService
    {
        //private readonly HttpClient _httpClient;
        //private readonly string _centrifugoUrl;
        //private readonly string _secret;

        //public CentrifugoService(string centrifugoUrl, string secret)
        //{
        //    _httpClient = new HttpClient();
        //    _centrifugoUrl = centrifugoUrl;
        //    _secret = secret;
        //}

        public static async Task<string> PublishMessageAsync(string channel, object message)
        {
            var requestData = new
            {
                method = "publish",
                @params = new // @params anahtar kelimesi kullanarak 'params' anahtar kelimesini koruyun
                {
                    channel = channel,
                    data = message
                }
            };

            var jsonContent = JsonConvert.SerializeObject(requestData);
            var httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");
            var requestMessage = new HttpRequestMessage(HttpMethod.Post, $"//localhost:8002/connection/websocket")
            {
                Content = httpContent
            };
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer 8e5641d6-d6e2-4485-9f3b-f877dadb88b0");
            try
            {
                var response = await httpClient.SendAsync(requestMessage);
                if (response.IsSuccessStatusCode)
                {
                    var res = await response.Content.ReadAsStringAsync();
                    return "başarılı";
                }
                else
                {
                    var res = await response.Content.ReadAsStringAsync();
                    return "başarılısızzzz";
                }
            }
            catch (Exception ex)
            {
                var mes = ex;
                throw;
            }
        }
    }
}
