﻿using Microsoft.Extensions.Options;
using System.Text.Json;
using talhatemel.Configurations;

public class ChatGptService
{
    private readonly HttpClient _httpClient;
    private readonly OpenAiConfig _config;

    public ChatGptService(OpenAiConfig config)
    {
        _config = config;
    }

    public ChatGptService(HttpClient httpClient, IOptions<OpenAiConfig> config)
    {
        _httpClient = httpClient;
        _config = config.Value;
    }

    public async Task<string> GetChatGptResponse(string prompt)
    {
        var requestBody = new
        {
            model = "gpt-3.5-turbo",
            prompt = prompt,
            max_tokens = 100
        };

        var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/completions")
        {
            Headers =
            {
                { "Authorization", $"Bearer {_config.Key}" }
            },
            Content = JsonContent.Create(requestBody)
        };

        var response = await _httpClient.SendAsync(request);
        response.EnsureSuccessStatusCode();

        var responseContent = await response.Content.ReadAsStringAsync();
        var responseJson = JsonDocument.Parse(responseContent);
        var chatGptResponse = responseJson.RootElement.GetProperty("choices")[0].GetProperty("text").GetString();

        return chatGptResponse;
    }
}
