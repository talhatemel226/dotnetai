﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using talhatemel.Configurations;

namespace talhatemel.Services
{
    [Authorize]
    public class OpenAiService : IOpenAiService
    {
        internal const string _requestUri = "https://api.openai.com/v1/chat/completions";
        private readonly HttpClient _httpClient;
        private readonly OpenAiConfig _config;

        public OpenAiService(HttpClient httpClient, IOptions<OpenAiConfig> config)
        {
            _httpClient = httpClient;
            _config = config.Value;
        }

        public async Task<string> CompleteSentence(string text)
        {
            var requestBody = new
            {
                model = "gpt-3.5-turbo",
                messages = new[]
                {
                    new { role = "user", content = text }
                }
            };

            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri(_requestUri),
                Headers =
                {
                    { "Authorization", $"Bearer {_config.Key}" }
                },
                Content = JsonContent.Create(requestBody)
            };
            var response = await _httpClient.SendAsync(request);
            var resMessage = await response.Content.ReadAsStringAsync();
            return resMessage;
        }
    }
}
