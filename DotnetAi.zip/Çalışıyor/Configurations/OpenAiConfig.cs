﻿namespace talhatemel.Configurations
{
    public class OpenAiConfig
    {
        public string Key { get; set; }
    }
}
