﻿namespace YourNamespace.Configurations
{
    public class GeminiConfig
    {
        public string ApiKey { get; set; }
    }
}
