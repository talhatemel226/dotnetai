﻿namespace talhatemel.Helpers
{
    public interface IJwtHelper
    {
        string GenerateToken(string userId); // Burada metod ismi 'GenerateToken' olmalı
    }
}
