﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using talhatemel.Services;

namespace talhatemel.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class OpenAiController : ControllerBase
    {
        private readonly ILogger<OpenAiController> _logger;
        private readonly IOpenAiService _openAiService;

        public OpenAiController(ILogger<OpenAiController> logger, IOpenAiService openAiService)
        {
            _logger = logger;
            _openAiService = openAiService;
        }

        public class CompleteSentenceRequest
        {
            public required string Text { get; set; }
        }

        [HttpPost]
        [Route("CompleteSentence")]
        public async Task<IActionResult> CompleteSentence([FromBody] CompleteSentenceRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.Text))
            {
                return BadRequest("The text field is required.");
            }

            var result = await _openAiService.CompleteSentence(request.Text);
            return Ok(result);
        }
    }
}
