﻿namespace talhatemel.Configurations
{
    public class JwtConfig
    {
        public string Key { get; set; } = string.Empty;
        public int ExpireMinutes { get; set; } = 43200; // 30 günün dakika cinsinden karşılığı
    }
}
