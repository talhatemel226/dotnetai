﻿namespace talhatemel.Services
{
    public interface IOpenAiService
    {
        Task<string> CompleteSentence(string text);
    }
}
