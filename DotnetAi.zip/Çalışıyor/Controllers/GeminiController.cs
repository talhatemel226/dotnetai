﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using talhatemel.Services;

namespace talhatemel.Controllers
{
    //[Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class GeminiController : ControllerBase
    {
        private readonly GeminiService _geminiService;
        //extension method
        public GeminiController(GeminiService geminiService)
        {
            _geminiService = geminiService;
        }

        [HttpPost("generate")] 
        public async Task<IActionResult> Generate([FromBody] UserInputModel input)
        {
            if (input == null || string.IsNullOrWhiteSpace(input.Text))
            {
                return BadRequest("Input text is required.");
            }

            var response = await _geminiService.GetAIResponseAsync(input.Text);

            return Ok(new { Response = response });
        }
        [HttpPost("SendMessageToCentrifugo")]
        public void aa()
        {
            _ = CentrifugoService.PublishMessageAsync("", "mesajım");
        }
    }

    public class UserInputModel
    {
        public string Text { get; set; }
    }
}
