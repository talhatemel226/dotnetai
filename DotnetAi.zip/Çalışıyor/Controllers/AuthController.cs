﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using talhatemel.Configurations;
using talhatemel.Helpers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IJwtHelper _jwtHelper;
    private readonly JwtConfig _jwtConfig;

    public AuthController(IJwtHelper jwtHelper, IOptions<JwtConfig> jwtConfig)
    {
        _jwtHelper = jwtHelper;
        _jwtConfig = jwtConfig.Value;
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginModel model)
    {
        // Basit bir kullanıcı doğrulama işlemi
        if (model.Username == "test" && model.Password == "password")
        {
            var token = _jwtHelper.GenerateToken(model.Username);
            return Ok(new { Token = token });
        }
        return Unauthorized();
    }

    [HttpGet("get-token")]
    public IActionResult GetToken()
    {
        // Test amaçlı bir kullanıcı adı veriyoruz
        var username = "test";
        var token = _jwtHelper.GenerateToken(username);
        return Ok(new { Token = token });
    }
}

public class LoginModel
{
    public string Username { get; set; }
    public string Password { get; set; }
}
